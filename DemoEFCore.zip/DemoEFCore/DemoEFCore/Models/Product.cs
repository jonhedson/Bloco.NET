﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoEFCore.Models
{
    class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
